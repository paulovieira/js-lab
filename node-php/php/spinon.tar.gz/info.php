<html>
    <head>
        
    </head>
    <body>

    this is page 1
    <?php
    print_r($_SERVER);
    ?>

        <a href="page2.php">link</a>

        <script src="xyz.js"></script>
    </body>
</html>
