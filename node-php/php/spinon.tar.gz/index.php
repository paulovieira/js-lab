<!doctype html>

<!-- get pages from menu -->
<?php

if(!$_GET["page"]){
$page="state";
} Else {
$page=$_GET["page"];
}
?>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Paper Dashboard PRO by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

	
    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>
	
	<!-- Weather Icons core CSS -->
	<link href="assets/css/weather-icons.min.css" rel="stylesheet"/>
	
	<!-- Weather Icons Fonts -->
	
	
	

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
	
</head>

<body>
	<div class="wrapper">
	    <div class="sidebar" data-background-color="brown" data-active-color="danger">
	    <!--
			Tip 1: you can change the color of the sidebar's background using: data-background-color="white | brown"
			Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
		-->
			<div class="logo">
				<a href="#" class="simple-text">
					Spin On
				</a>
			</div>
			<div class="logo logo-mini">
				<a href="#" class="simple-text">
					SO
				</a>
			</div>
	    	<div class="sidebar-wrapper">
				<div class="user">
	                <div class="photo">
	                    <img src="assets/img/faces/face-2.jpg" />
	                </div>
	                <div class="info">
	                    <a data-toggle="collapse" href="#collapseExample" class="collapsed">
	                        Anastácio Silva	
	                        <b class="caret"></b>
	                    </a>
	                    <div class="collapse" id="collapseExample">
	                        <ul class="nav">
	                            <li><a href="?page=user">Editar perfil</a></li>
	                            <li><a href="?page=users">Gerir utilizadores</a></li>
	                        </ul>
	                    </div>
	                </div>
	            </div>
	            <ul class="nav">
				<?php
					if ($page=="state"){
						$menu="active";
						
					} else {
						$menu="";	
					}
					?>
					<li class="<?php echo $menu ?>">
	                    <a href="?page=state">
	                        <i class="ti-eye"></i>
	                        <p>Estado</p>                     
	                    </a>
                        
	                </li>

					<?php
					if ($page=="control"){
						$menu="active";
						$submenu="collapse in";
					} else {
						$menu="";
						$submenu="collapse";
					}
					?>
					<li class="<?php echo $menu ?>">
	                    <a data-toggle="collapse" href="#dashboardOverview">
	                        <i class="ti-panel"></i>
	                        <p>Controlo
                                <b class="caret"></b>
                            </p>
	                    </a>
                        <div class="<?php echo $submenu ?>" id="dashboardOverview">
							<ul class="nav">
								<li class="<?php echo $menu ?>"><a href="?page=control">Campo das Faias</a></li>
								<li><a href="#">Campo das amoreiras</a></li>
								<li><a href="#">Campo pequeno</a></li>
								<li><a href="#">Pomar</a></li>
							</ul>
						</div>
	                </li>
					
					
					
	                <li>
	                    <a href="#charts">
	                        <i class="ti-bar-chart-alt"></i>
	                        <p>Análise</p>
	                    </a>
	                </li>
					<?php
					if ($page=="meteo"){
						$menu="active";
						
					} else {
						$menu="";	
					}
					?>
	                <li class="<?php echo $menu ?>">
	                    <a href="?page=meteo">
	                        <i class="ti-cloud"></i>
	                        <p>Meteorologia</p>
	                    </a>
	                </li>

<!-- alternative - icon from font-awesome 	                
					<li>
	                    <a href="#forecast">
	                        <i class="fa fa-cloud" aria-hidden="true"></i>
	                        <p>Meteorologia</p>
	                    </a>
	                </li> 
-->

	                <li>
	                    <a href="#reporting">
	                        <i class="ti-file" aria-hidden="true"></i>
	                        <p>Reporting</p>
	                    </a>
	                </li>
	            </ul>
	    	</div>
	    </div>

	    <div class="main-panel">
	        <nav class="navbar navbar-default">
	            <div class="container-fluid">
					<div class="navbar-minimize">
						<button id="minimizeSidebar" class="btn btn-fill btn-icon"><i class="ti-more-alt"></i></button>
					</div>
	                <div class="navbar-header">
	                    <button type="button" class="navbar-toggle">
	                        <span class="sr-only">Toggle navigation</span>
	                        <span class="icon-bar bar1"></span>
	                        <span class="icon-bar bar2"></span>
	                        <span class="icon-bar bar3"></span>
	                    </button>
	                    <a class="navbar-brand" href="#charts">Herdade do Freixo</a>
	                </div>
	                <div class="collapse navbar-collapse">
						<!--<form class="navbar-form navbar-left navbar-search-form" role="search">
	    					<div class="input-group">
	    						<span class="input-group-addon"><i class="fa fa-search"></i></span>
	    						<input type="text" value="" class="form-control" placeholder="Pesquisar...">
	    					</div>
	    				</form>-->
	                    <ul class="nav navbar-nav navbar-right">
	                        <!--<li>
	                            <a href="#stats" class="dropdown-toggle btn-magnify" data-toggle="dropdown">
	                                <i class="ti-panel"></i>
									<p>Stats</p>
	                            </a>
	                        </li>-->
	                        <li class="dropdown">
	                            <a href="#notifications" class="dropdown-toggle btn-rotate" data-toggle="dropdown">
	                                <i class="ti-bell"></i>
	                                <span class="notification">5</span>
									<p>
										Notifications <b class="caret"></b>
									</p>
	                            </a>
	                            <ul class="dropdown-menu">
	                                <li><a href="#not1">Notification 1</a></li>
	                                <li><a href="#not2">Notification 2</a></li>
	                                <li><a href="#not3">Notification 3</a></li>
	                                <li><a href="#not4">Notification 4</a></li>
	                                <li><a href="#another">Another notification</a></li>
	                            </ul>
	                        </li>
							<!--<li>
	                            <a href="#settings" class="btn-rotate">
									<i class="ti-settings"></i>
									<p>Settings</p>
	                            </a>
	                        </li>-->
	                    </ul>
	                </div>
	            </div>
	        </nav>

	        <div class="content">
	            <div class="container-fluid">
	                <div class="row">
					<!-- your content here -->
					<?php include "pages/$page.html";  ?>

					
						

	                </div>
	            </div>
	        </div>

	        <footer class="footer">
	            <div class="container-fluid">
	                <nav class="pull-left">
	                    <ul>
	                        <li>
	                            <a href="http://www.creative-tim.com">
	                                Creative Tim
	                            </a>
	                        </li>
	                        <li>
	                            <a href="http://blog.creative-tim.com">
	                               Blog
	                            </a>
	                        </li>
	                        <li>
	                            <a href="http://www.creative-tim.com/license">
	                                Licenses
	                            </a>
	                        </li>
	                    </ul>
	                </nav>
	                <div class="copyright pull-right">
	                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://www.creative-tim.com">Creative Tim</a>
	                </div>
	            </div>
	        </footer>
	    </div>
	</div>
<!-- modal start -->	
<div id="myControl" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
			</div>
			<div class="modal-body">
					<form method="" action="">
						<h5 class="text-center">Seleccione o tipo de acção.</h5>
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">
													Tipologia
												</label>
												<select class="form-control">
													<option selected="" disabled="">- seleccione uma opção -</option>
													<option value="rule">Regra</option>
													<option value="alert">Alerta</option>	
												</select>
											</div>
										</div>
										<div class="col-md-5">
											<div class="form-group">
												<label class="control-label">
													Acção
												</label>
												<select class="form-control">
													<option selected="" disabled="">- Escolha uma acção -</option>
													<option value="sms">Enviar sms</option>
													<option value="email">Enviar email</option>
													<option value="on">Ligar rega</option>
													<option value="off">Desligar rega</option>
													
												</select>
											</div>
										</div>
									</div>
									<h5 class="text-center">Seleccione as condições que deseja aplicar.</h5>
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Desligar após:</label>
												<input class="form-control"
													   type="number"
													   name="hourson"
													   placeholder="ex. xx horas"
												/>
											</div>
										</div>
										<div class="col-md-5">
												<label class="control-label">Ativar/Desativar</label>
												<p><input type="checkbox" data-toggle="switch"/></p>
										</div>	
									</div>
									
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Executar acção se o potencial hídrico está Alto?</label>	
											</div>
										</div>
										<div class="col-md-5">
												<br>
												<input type="checkbox" data-toggle="switch"/>
										</div>    
									</div>
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Executar acção se o potencial hídrico está baixo?</label>
												
											</div>
										</div>
										<div class="col-md-5">
										<br>
												<input type="checkbox" data-toggle="switch"/>
										</div>    
									</div>
							<button type="button" class="btn btn-info btn-fill btn-wd btn-finish pull-right" >Finalizar</button>
							<div class="clearfix"></div>	
					</form>	
			</div>
			<div class="modal-footer">
			  
			</div>
		</div>
	</div>
</div>
<!-- modal end -->	
</body>

	<!--   Core JS Files   -->
	<script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Forms Validations Plugin -->
	<script src="assets/js/jquery.validate.min.js"></script>

	<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
	<script src="assets/js/moment.min.js"></script>

	<!--  Date Time Picker Plugin is included in this js file -->
	<script src="assets/js/bootstrap-datetimepicker.js"></script>

	<!--  Select Picker Plugin -->
	<script src="assets/js/bootstrap-selectpicker.js"></script>

	<!--  Checkbox, Radio, Switch and Tags Input Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch-tags.js"></script>

	<!-- Circle Percentage-chart -->
	<script src="assets/js/jquery.easypiechart.min.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

	<!--  Notifications Plugin    -->
	<script src="assets/js/bootstrap-notify.js"></script>

	<!-- Sweet Alert 2 plugin -->
	<script src="assets/js/sweetalert2.js"></script>

	<!-- Vector Map plugin -->
	<script src="assets/js/jquery-jvectormap.js"></script>

	<!--  Google Maps Plugin    -->
	<script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Wizard Plugin    -->
	<script src="assets/js/jquery.bootstrap.wizard.min.js"></script>

	<!--  Datatable Plugin    -->
	<script src="assets/js/bootstrap-table.js"></script>

	<!--  Full Calendar Plugin    -->
	<script src="assets/js/fullcalendar.min.js"></script>

	<!-- Paper Dashboard PRO Core javascript and methods for Demo purpose-->
	<script src="assets/js/paper-dashboard.js"></script> 

	<!-- Paper Dashboard PRO DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

	
	<?php

	if(!$_GET["page"] OR !$_GET["page"]="state"){
	
	echo "<script type='text/javascript'>
    	$(document).ready(function(){
			demo.initOverviewDashboard();
			demo.initCirclePercentage();
    	});
	</script>";
	}
	If ($_GET["page"]="control") {
	echo "<script type='text/javascript'>
    	$(document).ready(function(){
			demo.initStatsDashboard();
			demo.initVectorMap();
			demo.initCirclePercentage();

    	});
	</script>";	
	}
	?>
	
	
	
</html>
