this is page 2
<?php
print_r($_SERVER);
?>
